package com.example.gisapp1.activities;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.gisapp1.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

public class AddParkingSpotActivity extends AppCompatActivity {

    private EditText etAddress, etAvailability, etPrice;
    private Button btnGetLocation, btnSaveParking;
    private FirebaseFirestore db;
    private FusedLocationProviderClient fusedLocationClient;
    private double latitude, longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_parking_spot);

        etAddress = findViewById(R.id.et_address);
        etAvailability = findViewById(R.id.et_availability);
        etPrice = findViewById(R.id.et_price);
        btnGetLocation = findViewById(R.id.btn_get_location);
        btnSaveParking = findViewById(R.id.btn_save_parking);

        db = FirebaseFirestore.getInstance();
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        btnGetLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCurrentLocation();
            }
        });

        btnSaveParking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveParkingSpot();
            }
        });
    }

    private void getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }

        Task<Location> task = fusedLocationClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                    Toast.makeText(AddParkingSpotActivity.this, "Location is successfully saved  !", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(AddParkingSpotActivity.this, "Location isn't reachable", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void saveParkingSpot() {
        String address = etAddress.getText().toString().trim();
        String availability = etAvailability.getText().toString().trim();
        String price = etPrice.getText().toString().trim();

        if (address.isEmpty() || availability.isEmpty() || price.isEmpty() || latitude == 0 || longitude == 0) {
            Toast.makeText(this, "Please fill al fields ans get you location", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, Object> parkingSpot = new HashMap<>();
        parkingSpot.put("address", address);
        parkingSpot.put("latitude", latitude);
        parkingSpot.put("longitude", longitude);
        parkingSpot.put("availability", availability);
        parkingSpot.put("price", Double.parseDouble(price));
        parkingSpot.put("status", "available");

        db.collection("parkingSpots")
                .add(parkingSpot)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(this, "Parking has been successfully saved!", Toast.LENGTH_SHORT).show();
                    finish(); // חוזר למסך הראשי
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Error with adding the parking", Toast.LENGTH_SHORT).show());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            getCurrentLocation();
        } else {
            Toast.makeText(this, "Location Permission is needed", Toast.LENGTH_SHORT).show();
        }
    }
}
